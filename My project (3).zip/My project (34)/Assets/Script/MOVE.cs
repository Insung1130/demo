using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class MOVE : MonoBehaviour
{
    [Header("Player Settings")]
    public float moveSpeed = 5f;   // �¿� �̵� �ӵ�
    public float jumpForce = 12f;  // ���� ��

    [Header("Ground Check Settings")]
    public Transform groundCheck;
    public float groundRadius = 0.2f; // groundCheck �ݰ�
    public LayerMask groundLayer;      // �ٴ� ���̾�

    Rigidbody2D rb;
    float moveInput;
    bool isGrounded = false;
    bool facingRight = true;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // �¿� �̵� �Է�
        moveInput = Input.GetAxisRaw("Horizontal");

        // �� üũ
        if (groundCheck != null)
        {
            isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer) != null;
            // Debug.Log("Grounded: " + isGrounded); // �ʿ��ϸ� �Ѽ� Ȯ��
        }

        // ���� �Է� (X Ű)
        if (Input.GetKeyDown(KeyCode.X) && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }

        // �¿� ���� ó��
        if (moveInput < 0 && !facingRight)
            Flip();
        else if (moveInput > 0 && facingRight)
            Flip();
    }

    void FixedUpdate()
    {
        // �¿� �̵�
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);
    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(groundCheck.position, groundRadius);
        }
    }
}
